angular.module('starter.controllers', [])

    /* Controller for home*/
    .controller('HomeCtrl', function ($scope) {})

    /* Controller for Themen*/
    .controller('ThemenCtrl', function ($scope) {})
